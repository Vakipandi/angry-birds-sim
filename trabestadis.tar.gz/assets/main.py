import asyncio
import pygame
import math
import random
import json

pygame.init()

WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Angry Birds - Simulacion")
clock = pygame.time.Clock()

SKY_TOP    = (135, 206, 235)
SKY_BOT    = (255, 220, 150)
GROUND_COL = (34, 139, 34)
MOUNTAIN   = (100, 120, 80)
MOUNTAIN2  = (130, 150, 100)
WHITE      = (255, 255, 255)
RED        = (220, 50, 50)
YELLOW     = (255, 220, 0)
GRAY       = (160, 160, 160)
BLACK      = (0, 0, 0)
ORANGE     = (255, 140, 0)
WOOD       = (180, 120, 50)
WOOD_DRK   = (140, 90, 30)
PIG        = (100, 200, 80)
PIG_DRK    = (70, 160, 50)

x0, y0   = 100, 490
GROUND_Y = 510
radius   = 13
g        = 0.4

PTS_CERDO  = 500
PTS_MADERA = 50

clouds   = [[100, 80, 0.3], [300, 50, 0.2], [550, 90, 0.25], [700, 60, 0.15]]
font     = pygame.font.SysFont("Arial", 18)
font_big = pygame.font.SysFont("Arial", 22, bold=True)
show_hitbox = False
show_grid   = False


def make_structure():
    W, TH    = 70, 10
    p1r, p2r = 14, 12
    bx       = random.randint(480, 660)
    cx       = bx + W // 2
    p1y      = GROUND_Y - p1r
    roof_y   = p1y - p1r - TH
    p2y      = roof_y - p2r
    boards = [
        [pygame.Rect(bx,          roof_y, TH, GROUND_Y - roof_y), 0.0, 0.0],
        [pygame.Rect(bx + W - TH, roof_y, TH, GROUND_Y - roof_y), 0.0, 0.0],
        [pygame.Rect(bx,          roof_y, W,  TH), 0.0, 0.0],
    ]
    pigs = [
        [cx, p1y, p1r, True, 0.0, 0.0],
        [cx, p2y, p2r, True, 0.0, 0.0],
    ]
    return {"boards": boards, "pigs": pigs}


def apply_impulse(obj_x, obj_y, bx, by, strength):
    dx = obj_x - bx
    dy = obj_y - by
    dist = math.hypot(dx, dy) or 1
    return (dx / dist) * strength, (dy / dist) * strength - 3


def update_physics(st):
    for board in st["boards"]:
        if board[1] != 0 or board[2] != 0:
            board[0].x += int(board[1])
            board[0].y += int(board[2])
            board[2] += g * 0.6
    for pig in st["pigs"]:
        if pig[4] != 0 or pig[5] != 0:
            pig[0] += pig[4]
            pig[1] += pig[5]
            pig[5] += g
            if pig[1] + pig[2] >= GROUND_Y:
                pig[1] = GROUND_Y - pig[2]
                pig[3] = False
                pig[4] = pig[5] = 0.0


def draw_background(tick):
    for i in range(HEIGHT):
        t  = i / HEIGHT
        r  = int(SKY_TOP[0] + (SKY_BOT[0] - SKY_TOP[0]) * t)
        gv = int(SKY_TOP[1] + (SKY_BOT[1] - SKY_TOP[1]) * t)
        b  = int(SKY_TOP[2] + (SKY_BOT[2] - SKY_TOP[2]) * t)
        pygame.draw.line(screen, (r, gv, b), (0, i), (WIDTH, i))
    mts2 = [(0,420),(80,300),(180,360),(300,280),(420,340),(540,260),(660,320),(800,420)]
    pygame.draw.polygon(screen, MOUNTAIN2, mts2 + [(800, HEIGHT), (0, HEIGHT)])
    mts  = [(0,450),(60,350),(150,390),(260,310),(370,370),(480,290),(600,350),(720,380),(800,450)]
    pygame.draw.polygon(screen, MOUNTAIN,  mts  + [(800, HEIGHT), (0, HEIGHT)])
    for c in clouds:
        c[0] = (c[0] + c[2]) % (WIDTH + 100)
        cx, cy = int(c[0]), int(c[1])
        pygame.draw.ellipse(screen, WHITE, (cx,    cy,     80, 35))
        pygame.draw.ellipse(screen, WHITE, (cx+15, cy-15,  55, 35))
        pygame.draw.ellipse(screen, WHITE, (cx+35, cy,     60, 30))
    pygame.draw.rect(screen, GROUND_COL, (0, GROUND_Y, WIDTH, HEIGHT - GROUND_Y))
    pygame.draw.line(screen, (20,100,20), (0, GROUND_Y), (WIDTH, GROUND_Y), 3)
    sx = int(650 + 30 * math.sin(tick * 0.001))
    pygame.draw.circle(screen, YELLOW, (sx, 60), 35)
    pygame.draw.circle(screen, (255,255,180), (sx, 60), 28)


def draw_structure(st):
    for board in st["boards"]:
        rect = board[0]
        pygame.draw.rect(screen, WOOD, rect)
        pygame.draw.rect(screen, WOOD_DRK, rect, 2)
        if show_hitbox:
            pygame.draw.rect(screen, (255, 0, 255), rect, 1)
    for pig in st["pigs"]:
        px, py, pr, alive = pig[0], pig[1], pig[2], pig[3]
        if not alive:
            continue
        pygame.draw.circle(screen, PIG,     (int(px), int(py)), pr)
        pygame.draw.circle(screen, PIG_DRK, (int(px), int(py)), pr, 2)
        pygame.draw.circle(screen, (80,50,30), (int(px), int(py)+4), 4)
        pygame.draw.circle(screen, BLACK,    (int(px)-4, int(py)-3), 2)
        pygame.draw.circle(screen, BLACK,    (int(px)+4, int(py)-3), 2)
        if show_hitbox:
            pygame.draw.circle(screen, (255, 0, 255), (int(px), int(py)), pr, 1)


def draw_bird(bx, by):
    pygame.draw.circle(screen, RED,    (int(bx), int(by)), radius)
    pygame.draw.circle(screen, ORANGE, (int(bx)+4, int(by)-4), 5)
    pygame.draw.circle(screen, BLACK,  (int(bx)+5, int(by)-6), 2)
    if show_hitbox:
        pygame.draw.circle(screen, (255, 0, 255), (int(bx), int(by)), radius, 1)


def draw_slingshot():
    pygame.draw.line(screen, (100,60,20), (x0, y0+5), (x0-10, y0-25), 6)
    pygame.draw.line(screen, (100,60,20), (x0, y0+5), (x0+10, y0-25), 6)
    pygame.draw.line(screen, (100,60,20), (x0, y0+5), (x0,    y0+30), 8)


def draw_charge_indicator(pct):
    bar_w  = 60
    filled = int(bar_w * pct)
    color  = (int(255 * pct), int(200 * (1 - pct)), 0)
    pygame.draw.rect(screen, GRAY,  (x0-30, y0-35, bar_w, 8))
    pygame.draw.rect(screen, color, (x0-30, y0-35, filled, 8))
    pygame.draw.rect(screen, BLACK, (x0-30, y0-35, bar_w,  8), 1)


def draw_aim_line(pct):
    mx, my = pygame.mouse.get_pos()
    a   = math.atan2(y0 - my, mx - x0)
    sp  = pct * 15
    tvx = sp * math.cos(a)
    tvy = -sp * math.sin(a)
    px, py = float(x0), float(y0)
    for i in range(50):
        px += tvx; py += tvy; tvy += g
        if py > GROUND_Y: break
        if i % 3 == 0:
            pygame.draw.circle(screen, (200,200,200), (int(px), int(py)), 2)


def draw_grid():
    grid_surf = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
    cell, scale = 25, 10
    ox, oy = x0, GROUND_Y
    for gx in range(0, WIDTH, cell):
        coord = ((gx - ox) // cell) * scale
        alpha = 180 if coord % 50 == 0 else 60
        pygame.draw.line(grid_surf, (0, 0, 0, alpha), (gx, 0), (gx, HEIGHT), 1)
        if coord % 50 == 0 and coord != 0:
            grid_surf.blit(font.render(str(coord), True, (0,0,0,220)), (gx+2, oy+4))
    for gy in range(0, HEIGHT, cell):
        coord = ((oy - gy) // cell) * scale
        alpha = 180 if coord % 50 == 0 else 60
        pygame.draw.line(grid_surf, (0, 0, 0, alpha), (0, gy), (WIDTH, gy), 1)
        if coord % 50 == 0 and coord != 0:
            grid_surf.blit(font.render(str(coord), True, (0,0,0,220)), (ox+4, gy+2))
    pygame.draw.line(grid_surf, (200,0,0,220), (0, oy), (WIDTH, oy), 2)
    pygame.draw.line(grid_surf, (200,0,0,220), (ox, 0), (ox, HEIGHT), 2)
    grid_surf.blit(font.render("0", True, (200,0,0,220)), (ox+4, oy+4))
    screen.blit(grid_surf, (0, 0))


async def main():
    global show_hitbox, show_grid

    st               = make_structure()
    data             = []
    partida_intentos = []
    shooting         = False
    charging         = False
    charge_start     = 0
    vx = vy          = 0.0
    x, y             = float(x0), float(y0)
    angle = speed    = 0.0
    intentos         = 0
    puntaje_total    = 0
    trail            = []
    full_trail       = []
    partida_num      = 1
    tablas_hit       = 0
    cerdos_nuevos    = 0
    tick             = 0

    running = True
    while running:
        clock.tick(60)
        tick += 1
        draw_background(tick)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if event.type == pygame.KEYDOWN and event.key == pygame.K_h:
                show_hitbox = not show_hitbox
            if event.type == pygame.KEYDOWN and event.key == pygame.K_g:
                show_grid = not show_grid

            if event.type == pygame.MOUSEBUTTONDOWN and not shooting:
                charging     = True
                charge_start = tick

            if event.type == pygame.MOUSEBUTTONUP and charging and not shooting:
                held   = (tick - charge_start) / 60.0
                pct    = min(held / 2.0, 1.0)
                mx, my = pygame.mouse.get_pos()
                angle  = math.atan2(y0 - my, mx - x0)
                speed  = pct * 15
                vx     = speed * math.cos(angle)
                vy     = -speed * math.sin(angle)
                shooting     = True
                charging     = False
                x, y         = float(x0), float(y0)
                trail.clear()
                full_trail   = []
                intentos    += 1
                tablas_hit   = 0
                cerdos_nuevos = 0

        if charging:
            held = (tick - charge_start) / 60.0
            pct  = min(held / 2.0, 1.0)
            draw_aim_line(pct)
            draw_charge_indicator(pct)

        if shooting:
            x += vx; y += vy; vy += g
            trail.append((int(x), int(y)))
            full_trail.append((int(x), int(y)))
            if len(trail) > 60:
                trail.pop(0)

            hit_any = False

            for board in st["boards"]:
                rect = board[0]
                if rect.collidepoint(x, y):
                    hit_any = True
                    tablas_hit += 1
                    ivx, ivy = apply_impulse(rect.centerx, rect.centery, x, y, 8)
                    board[1] += ivx; board[2] += ivy
                    for pig in st["pigs"]:
                        if pig[3] and math.hypot(rect.centerx - pig[0], rect.centery - pig[1]) < pig[2] + 30:
                            pvx, pvy = apply_impulse(pig[0], pig[1], x, y, 6)
                            pig[4] += pvx; pig[5] += pvy

            cerdos_antes = sum(1 for p in st["pigs"] if not p[3])
            for pig in st["pigs"]:
                if pig[3] and math.hypot(x - pig[0], y - pig[1]) <= pig[2] + radius:
                    hit_any = True
                    pig[3] = False
                    pvx, pvy = apply_impulse(pig[0], pig[1], x, y, 9)
                    pig[4] += pvx; pig[5] += pvy
            for board in st["boards"]:
                if board[1] != 0 or board[2] != 0:
                    for pig in st["pigs"]:
                        if pig[3] and math.hypot(board[0].centerx - pig[0], board[0].centery - pig[1]) < pig[2] + 15:
                            pig[3] = False
            cerdos_nuevos = sum(1 for p in st["pigs"] if not p[3]) - cerdos_antes

            stopped = y >= GROUND_Y or hit_any or x > WIDTH

            if stopped:
                distance   = x - x0
                pts_cerdos = cerdos_nuevos * PTS_CERDO
                pts_madera = tablas_hit * PTS_MADERA
                puntaje    = pts_cerdos + pts_madera
                puntaje_total += puntaje

                tiro = {
                    "partida":           partida_num,
                    "intento":           intentos,
                    "angulo":            round(math.degrees(angle), 2),
                    "velocidad":         round(speed, 2),
                    "distancia":         round(distance, 2),
                    "tablas_golpeadas":  tablas_hit,
                    "cerdos_derribados": cerdos_nuevos,
                    "pts_madera":        pts_madera,
                    "pts_cerdos":        pts_cerdos,
                    "puntaje_intento":   puntaje,
                    "puntaje_acumulado": puntaje_total,
                    "B_x": round((min(full_trail, key=lambda p: p[1])[0] - x0) / 25 * 10, 1) if full_trail else 0,
                    "B_y": round((GROUND_Y - min(full_trail, key=lambda p: p[1])[1]) / 25 * 10, 1) if full_trail else 0,
                    "C_x": round((full_trail[-1][0] - x0) / 25 * 10, 1) if full_trail else 0,
                }
                data.append(tiro)
                partida_intentos.append(tiro)
                print(tiro)
                shooting = False
                trail.clear()

                if all(not p[3] for p in st["pigs"]):
                    print(f"\n=== Partida {partida_num} — {intentos} intentos | Puntaje: {puntaje_total} ===")
                    # guardar en localStorage (solo funciona en web)
                    try:
                        import platform
                        if platform.system() == "Emscripten":
                            import js
                            js.localStorage.setItem("datos_juego", json.dumps(data))
                    except Exception:
                        pass
                    partida_num     += 1
                    intentos         = 0
                    partida_intentos = []
                    full_trail.clear()
                    st = make_structure()

        update_physics(st)

        if len(full_trail) > 1:
            for i in range(1, len(full_trail)):
                p1 = full_trail[i-1]
                p2 = full_trail[i]
                # solo dibuja si los puntos son consecutivos (no saltos grandes)
                if abs(p2[0] - p1[0]) < 30 and abs(p2[1] - p1[1]) < 30:
                    pygame.draw.line(screen, (255, 80, 80), p1, p2, 2)

        for i, (tx, ty) in enumerate(trail):
            alpha = int(200 * i / max(len(trail), 1))
            pygame.draw.circle(screen, (alpha, alpha, 255), (tx, ty), 3)

        draw_slingshot()
        draw_structure(st)
        draw_bird(x, y)

        for i, txt in enumerate([
            f"Partida: {partida_num}",
            f"Intentos: {intentos}",
            f"Angulo: {round(math.degrees(angle),1)}",
            f"Velocidad: {round(speed,1)}",
            f"Puntaje: {puntaje_total}",
            f"Cerdo +{PTS_CERDO}  Madera +{PTS_MADERA}",
        ]):
            screen.blit(font_big.render(txt, True, BLACK), (10, 10 + i * 26))

        if show_grid:
            draw_grid()

        if not shooting and not charging:
            hint = font.render("H=hitbox | G=grilla | Manten clic y suelta para lanzar", True, BLACK)
            screen.blit(hint, (WIDTH//2 - hint.get_width()//2, HEIGHT - 30))

        pygame.display.flip()
        await asyncio.sleep(0)

asyncio.run(main())
