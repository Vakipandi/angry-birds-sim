import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

df = pd.read_csv("datos_juego.csv")

# variable cualitativa: exito si derribo al menos un cerdo
df["resultado"] = df["cerdos_derribados"].apply(lambda x: "Éxito" if x > 0 else "Fracaso")

# ── GRÁFICO 1: Éxito vs Fracaso ──────────────────────────────────────────────
conteo = df["resultado"].value_counts()

fig, ax = plt.subplots(figsize=(7, 5))
colores = ["#4CAF50" if r == "Éxito" else "#F44336" for r in conteo.index]
bars = ax.bar(conteo.index, conteo.values, color=colores, edgecolor="black", width=0.5)

for bar, val in zip(bars, conteo.values):
    ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.3,
            str(val), ha="center", va="bottom", fontsize=13, fontweight="bold")

total = len(df)
ax.set_title("Gráfico 1 — Frecuencia de intentos: Éxito vs Fracaso", fontsize=13, fontweight="bold")
ax.set_xlabel("Resultado del intento", fontsize=11)
ax.set_ylabel("Frecuencia (cantidad de intentos)", fontsize=11)
ax.set_ylim(0, conteo.max() + 4)

exito_pct  = round(conteo.get("Éxito",  0) / total * 100, 1)
fracaso_pct = round(conteo.get("Fracaso", 0) / total * 100, 1)
parche_e = mpatches.Patch(color="#4CAF50", label=f"Éxito: {conteo.get('Éxito',0)} ({exito_pct}%)")
parche_f = mpatches.Patch(color="#F44336", label=f"Fracaso: {conteo.get('Fracaso',0)} ({fracaso_pct}%)")
ax.legend(handles=[parche_e, parche_f], fontsize=10)
ax.grid(axis="y", alpha=0.3)
plt.tight_layout()
plt.savefig("grafico1_exito_fracaso.png", dpi=150)
plt.show()
print("Gráfico 1 guardado.")

# ── GRÁFICO 2: Puntaje promedio según nivel de impacto ───────────────────────
def nivel_impacto(row):
    total_impacto = row["cerdos_derribados"] + row["tablas_golpeadas"]
    if total_impacto == 0:
        return "Sin impacto"
    elif total_impacto <= 2:
        return "Impacto medio"
    else:
        return "Alto impacto"

df["nivel_impacto"] = df.apply(nivel_impacto, axis=1)

orden  = ["Sin impacto", "Impacto medio", "Alto impacto"]
promedios = df.groupby("nivel_impacto")["puntaje_intento"].mean().reindex(orden)
conteos   = df.groupby("nivel_impacto")["puntaje_intento"].count().reindex(orden)

fig, ax = plt.subplots(figsize=(8, 5))
colores2 = ["#9E9E9E", "#FF9800", "#2196F3"]
bars2 = ax.bar(orden, promedios.values, color=colores2, edgecolor="black", width=0.5)

for bar, val, n in zip(bars2, promedios.values, conteos.values):
    ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 5,
            f"{round(val)}\n(n={n})", ha="center", va="bottom", fontsize=11, fontweight="bold")

ax.set_title("Gráfico 2 — Puntaje promedio según nivel de impacto", fontsize=13, fontweight="bold")
ax.set_xlabel("Nivel de impacto", fontsize=11)
ax.set_ylabel("Puntaje promedio por intento", fontsize=11)
ax.set_ylim(0, promedios.max() + 150)
ax.grid(axis="y", alpha=0.3)

parches = [mpatches.Patch(color=c, label=f"{n}: {round(p)} pts promedio")
           for c, n, p in zip(colores2, orden, promedios.values)]
ax.legend(handles=parches, fontsize=10)
plt.tight_layout()
plt.savefig("grafico2_puntaje_impacto.png", dpi=150)
plt.show()
print("Gráfico 2 guardado.")

# resumen en consola
print(f"\nTotal intentos: {total}")
print(f"  Éxito:   {conteo.get('Éxito',0)} ({exito_pct}%)")
print(f"  Fracaso: {conteo.get('Fracaso',0)} ({fracaso_pct}%)")
print(f"\nPuntaje promedio por nivel de impacto:")
for nivel, prom, n in zip(orden, promedios.values, conteos.values):
    print(f"  {nivel:15}: {round(prom)} pts  (n={n})")
