import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

df = pd.read_csv("datos_juego.csv")

tiro = df.dropna(subset=["B_x", "B_y", "C_x"]).iloc[-1]

A = (0, 0)
B = (tiro["B_x"], tiro["B_y"])   # punto mas alto registrado en simulacion
C = (tiro["C_x"], 0)

print("Puntos obtenidos de la simulacion:")
print(f"  A = {A}")
print(f"  B = {B}  <- punto mas alto registrado")
print(f"  C = {C}")

# --- construir funcion cuadratica ---
# A y C son raices => f(x) = a * x * (x - x_c)
# sustituir B para hallar 'a'
x_b, y_b = B
x_c = C[0]

a = y_b / (x_b * (x_b - x_c))
b_coef = -a * x_c   # coeficiente de x en forma expandida

print(f"\nFuncion cuadratica construida con los 3 puntos:")
print(f"  f(x) = {round(a, 6)} * x * (x - {x_c})")
print(f"  f(x) = {round(a, 6)}x^2 + {round(b_coef, 6)}x")

# --- vertice teorico: x = -b / 2a ---
x_vert_teo = -b_coef / (2 * a)          # = x_c / 2
y_vert_teo = a * x_vert_teo * (x_vert_teo - x_c)

print(f"\nVertice teorico (altura maxima segun la funcion):")
print(f"  x_vertice = -({round(b_coef,4)}) / (2 * {round(a,6)}) = {round(x_vert_teo, 2)}")
print(f"  y_vertice = f({round(x_vert_teo,2)}) = {round(y_vert_teo, 2)}")

print(f"\nComparacion simulacion vs teoria:")
print(f"  {'':25} {'Simulacion':>12} {'Teoria':>12} {'Error %':>10}")
print(f"  {'Altura maxima (y)':25} {y_b:>12} {round(y_vert_teo,2):>12} {round(abs(y_vert_teo - y_b)/y_b*100, 2) if y_b else 0:>9}%")
print(f"  {'X en altura max':25} {x_b:>12} {round(x_vert_teo,2):>12} {round(abs(x_vert_teo - x_b)/x_b*100, 2) if x_b else 0:>9}%")
print(f"  {'Distancia total (x)':25} {x_c:>12} {round(x_c,2):>12} {'0.0':>9}%")

# --- grafico ---
x_vals = np.linspace(0, x_c * 1.05, 500)
y_vals = a * x_vals * (x_vals - x_c)

fig, ax = plt.subplots(figsize=(10, 5))
ax.plot(x_vals, y_vals, "b-", linewidth=2, label=f"f(x) = {round(a,5)}x(x - {x_c})")

# puntos de simulacion
ax.scatter([A[0], B[0], C[0]], [A[1], B[1], C[1]],
           color=["green", "red", "orange"], s=80, zorder=5,
           label="Puntos simulacion (A, B, C)")

# vertice teorico
ax.scatter([x_vert_teo], [y_vert_teo], color="blue", marker="^", s=100, zorder=6,
           label=f"Vertice teorico ({round(x_vert_teo,1)}, {round(y_vert_teo,1)})")

for label, pt in zip(["A", "B (sim)", "C"], [A, B, C]):
    ax.annotate(f"{label}{pt}", pt, textcoords="offset points", xytext=(8, 8), fontsize=9)
ax.annotate(f"Vertice teo\n({round(x_vert_teo,1)}, {round(y_vert_teo,1)})",
            (x_vert_teo, y_vert_teo), textcoords="offset points", xytext=(8, -20),
            color="blue", fontsize=9)

ax.axhline(0, color="black", linewidth=0.8)
ax.axvline(0, color="black", linewidth=0.8)
ax.grid(True, alpha=0.3)
ax.set_title(f"Validacion trayectoria — Partida {int(tiro['partida'])}, Intento {int(tiro['intento'])}")
ax.set_xlabel("Distancia horizontal")
ax.set_ylabel("Altura")
ax.legend()
plt.tight_layout()
plt.savefig("validacion_trayectoria.png", dpi=150)
plt.show()
print("\nGrafico guardado en validacion_trayectoria.png")
