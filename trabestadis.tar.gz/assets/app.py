import pygame
import math
import pandas as pd
import random

pygame.init()

WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
clock = pygame.time.Clock()

SKY_TOP    = (135, 206, 235)
SKY_BOT    = (255, 220, 150)
GROUND_COL = (34, 139, 34)
MOUNTAIN   = (100, 120, 80)
MOUNTAIN2  = (130, 150, 100)
WHITE      = (255, 255, 255)
RED        = (220, 50, 50)
YELLOW     = (255, 220, 0)
GRAY       = (160, 160, 160)
BLACK      = (0, 0, 0)
ORANGE     = (255, 140, 0)
WOOD       = (180, 120, 50)
WOOD_DRK   = (140, 90, 30)
PIG        = (100, 200, 80)
PIG_DRK    = (70, 160, 50)

x0, y0   = 100, 490
GROUND_Y = 510
radius   = 13
g        = 0.4

# puntos por tipo
PTS_CERDO  = 500
PTS_MADERA = 50
PTS_BONUS  = [600, 300, 100]  # bonus por intento 1, 2, 3+

clouds   = [[100, 80, 0.3], [300, 50, 0.2], [550, 90, 0.25], [700, 60, 0.15]]
font     = pygame.font.SysFont("Arial", 18)
font_big = pygame.font.SysFont("Arial", 22, bold=True)
show_hitbox = False
show_grid   = False


def make_structure():
    W, TH    = 70, 10
    p1r, p2r = 14, 12
    bx       = random.randint(480, 660)
    cx       = bx + W // 2
    p1y      = GROUND_Y - p1r
    roof_y   = p1y - p1r - TH
    p2y      = roof_y - p2r

    # cada tabla: [rect, vx, vy]
    boards = [
        [pygame.Rect(bx,          roof_y,  TH, GROUND_Y - roof_y), 0.0, 0.0],  # izq
        [pygame.Rect(bx + W - TH, roof_y,  TH, GROUND_Y - roof_y), 0.0, 0.0],  # der
        [pygame.Rect(bx,          roof_y,  W,  TH),  0.0, 0.0],  # techo
    ]
    # cada cerdo: [x, y, r, alive, vx, vy]
    pigs = [
        [cx, p1y, p1r, True, 0.0, 0.0],
        [cx, p2y, p2r, True, 0.0, 0.0],
    ]
    return {"boards": boards, "pigs": pigs}


st = make_structure()

data             = []   # datos por partida
partida_intentos = []
shooting         = False
charging         = False
charge_start     = 0
vx = vy          = 0.0
x, y             = float(x0), float(y0)
angle = speed    = 0.0
intentos         = 0
puntaje_total    = 0
derribadas_total = 0
trail            = []
full_trail       = []  # lista de trails, cada tiro es una sublista
partida_num      = 1
tablas_hit       = 0
cerdos_nuevos    = 0


def draw_background(tick):
    for i in range(HEIGHT):
        t  = i / HEIGHT
        r  = int(SKY_TOP[0] + (SKY_BOT[0] - SKY_TOP[0]) * t)
        gv = int(SKY_TOP[1] + (SKY_BOT[1] - SKY_TOP[1]) * t)
        b  = int(SKY_TOP[2] + (SKY_BOT[2] - SKY_TOP[2]) * t)
        pygame.draw.line(screen, (r, gv, b), (0, i), (WIDTH, i))
    mts2 = [(0,420),(80,300),(180,360),(300,280),(420,340),(540,260),(660,320),(800,420)]
    pygame.draw.polygon(screen, MOUNTAIN2, mts2 + [(800, HEIGHT), (0, HEIGHT)])
    mts  = [(0,450),(60,350),(150,390),(260,310),(370,370),(480,290),(600,350),(720,380),(800,450)]
    pygame.draw.polygon(screen, MOUNTAIN,  mts  + [(800, HEIGHT), (0, HEIGHT)])
    for c in clouds:
        c[0] = (c[0] + c[2]) % (WIDTH + 100)
        cx, cy = int(c[0]), int(c[1])
        pygame.draw.ellipse(screen, WHITE, (cx,    cy,     80, 35))
        pygame.draw.ellipse(screen, WHITE, (cx+15, cy-15,  55, 35))
        pygame.draw.ellipse(screen, WHITE, (cx+35, cy,     60, 30))
    pygame.draw.rect(screen, GROUND_COL, (0, GROUND_Y, WIDTH, HEIGHT - GROUND_Y))
    pygame.draw.line(screen, (20,100,20), (0, GROUND_Y), (WIDTH, GROUND_Y), 3)
    sx = int(650 + 30 * math.sin(tick * 0.001))
    pygame.draw.circle(screen, YELLOW, (sx, 60), 35)
    pygame.draw.circle(screen, (255,255,180), (sx, 60), 28)


def draw_structure():
    for board in st["boards"]:
        rect = board[0]
        pygame.draw.rect(screen, WOOD, rect)
        pygame.draw.rect(screen, WOOD_DRK, rect, 2)
        if show_hitbox:
            pygame.draw.rect(screen, (255, 0, 255), rect, 1)

    for pig in st["pigs"]:
        px, py, pr, alive = pig[0], pig[1], pig[2], pig[3]
        if not alive:
            continue
        pygame.draw.circle(screen, PIG,     (int(px), int(py)), pr)
        pygame.draw.circle(screen, PIG_DRK, (int(px), int(py)), pr, 2)
        pygame.draw.circle(screen, (80,50,30), (int(px), int(py)+4), 4)
        pygame.draw.circle(screen, BLACK,    (int(px)-4, int(py)-3), 2)
        pygame.draw.circle(screen, BLACK,    (int(px)+4, int(py)-3), 2)
        if show_hitbox:
            pygame.draw.circle(screen, (255, 0, 255), (int(px), int(py)), pr, 1)


def draw_bird(bx, by):
    pygame.draw.circle(screen, RED,    (int(bx), int(by)), radius)
    pygame.draw.circle(screen, ORANGE, (int(bx)+4, int(by)-4), 5)
    pygame.draw.circle(screen, BLACK,  (int(bx)+5, int(by)-6), 2)
    if show_hitbox:
        pygame.draw.circle(screen, (255, 0, 255), (int(bx), int(by)), radius, 1)


def draw_slingshot():
    pygame.draw.line(screen, (100,60,20), (x0, y0+5), (x0-10, y0-25), 6)
    pygame.draw.line(screen, (100,60,20), (x0, y0+5), (x0+10, y0-25), 6)
    pygame.draw.line(screen, (100,60,20), (x0, y0+5), (x0,    y0+30), 8)


def draw_charge_indicator(pct):
    bar_w  = 60
    filled = int(bar_w * pct)
    color  = (int(255 * pct), int(200 * (1 - pct)), 0)
    pygame.draw.rect(screen, GRAY,  (x0-30, y0-35, bar_w, 8))
    pygame.draw.rect(screen, color, (x0-30, y0-35, filled, 8))
    pygame.draw.rect(screen, BLACK, (x0-30, y0-35, bar_w,  8), 1)


def draw_aim_line(pct):
    mx, my = pygame.mouse.get_pos()
    a   = math.atan2(y0 - my, mx - x0)
    sp  = pct * 15
    tvx = sp * math.cos(a)
    tvy = -sp * math.sin(a)
    px, py = float(x0), float(y0)
    for i in range(50):
        px += tvx; py += tvy; tvy += g
        if py > GROUND_Y: break
        if i % 3 == 0:
            pygame.draw.circle(screen, (200,200,200), (int(px), int(py)), 2)


def apply_impulse(obj_x, obj_y, bx, by, strength):
    """Calcula impulso desde punto de impacto (bx,by) hacia el objeto (obj_x, obj_y)."""
    dx = obj_x - bx
    dy = obj_y - by
    dist = math.hypot(dx, dy) or 1
    return (dx / dist) * strength, (dy / dist) * strength - 3


def update_physics():
    """Mueve tablas y cerdos que están volando."""
    for board in st["boards"]:
        if board[1] != 0 or board[2] != 0:
            board[0].x += int(board[1])
            board[0].y += int(board[2])
            board[2] += g * 0.6
    for pig in st["pigs"]:
        if pig[4] != 0 or pig[5] != 0:
            pig[0] += pig[4]
            pig[1] += pig[5]
            pig[5] += g
            # muere al tocar el suelo
            if pig[1] + pig[2] >= GROUND_Y:
                pig[1] = GROUND_Y - pig[2]
                pig[3] = False
                pig[4] = pig[5] = 0.0


tick    = 0
running = True
while running:
    clock.tick(120)  # 120 FPS para mayor precision en el muestreo
    tick += 1
    draw_background(tick)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.KEYDOWN and event.key == pygame.K_h:
            show_hitbox = not show_hitbox
        if event.type == pygame.KEYDOWN and event.key == pygame.K_g:
            show_grid = not show_grid

        if event.type == pygame.MOUSEBUTTONDOWN and not shooting:
            charging     = True
            charge_start = tick

        if event.type == pygame.MOUSEBUTTONUP and charging and not shooting:
            held   = (tick - charge_start) / 60.0
            pct    = min(held / 2.0, 1.0)
            mx, my = pygame.mouse.get_pos()
            angle  = math.atan2(y0 - my, mx - x0)
            speed  = pct * 15
            vx     = speed * math.cos(angle)
            vy     = -speed * math.sin(angle)
            shooting = True
            charging = False
            x, y   = float(x0), float(y0)
            trail.clear()
            full_trail = []  # reinicia trayectoria en cada intento
            full_trail.append([])  # nuevo tiro = nueva sublista
            intentos += 1
            tablas_hit = 0
            cerdos_nuevos = 0

    if charging:
        held = (tick - charge_start) / 60.0
        pct  = min(held / 2.0, 1.0)
        draw_aim_line(pct)
        draw_charge_indicator(pct)

    if shooting:
        x += vx; y += vy; vy += g
        trail.append((int(x), int(y)))
        if full_trail:
            full_trail[-1].append((int(x), int(y)))
        if len(trail) > 60:
            trail.pop(0)

        hit_any       = False

        # colisión con tablas
        for board in st["boards"]:
            rect = board[0]
            if rect.collidepoint(x, y):
                hit_any = True
                tablas_hit += 1
                ivx, ivy = apply_impulse(rect.centerx, rect.centery, x, y, 8)
                board[1] += ivx; board[2] += ivy
                for pig in st["pigs"]:
                    if pig[3] and math.hypot(rect.centerx - pig[0], rect.centery - pig[1]) < pig[2] + 30:
                        pvx, pvy = apply_impulse(pig[0], pig[1], x, y, 6)
                        pig[4] += pvx; pig[5] += pvy

        # colisión directa con cerdos
        cerdos_antes = sum(1 for p in st["pigs"] if not p[3])
        for pig in st["pigs"]:
            if pig[3] and math.hypot(x - pig[0], y - pig[1]) <= pig[2] + radius:
                hit_any = True
                pig[3] = False
                pvx, pvy = apply_impulse(pig[0], pig[1], x, y, 9)
                pig[4] += pvx; pig[5] += pvy
        # tablas que matan cerdo cercano
        for board in st["boards"]:
            if board[1] != 0 or board[2] != 0:  # tabla en movimiento
                for pig in st["pigs"]:
                    if pig[3] and math.hypot(board[0].centerx - pig[0], board[0].centery - pig[1]) < pig[2] + 15:
                        pig[3] = False
        cerdos_nuevos = sum(1 for p in st["pigs"] if not p[3]) - cerdos_antes

        stopped = y >= GROUND_Y or hit_any or x > WIDTH

        if stopped:
            distance      = x - x0
            derribadas    = sum(1 for p in st["pigs"] if not p[3])
            derribadas_total += cerdos_nuevos
            bonus         = 0  # sin bonus
            pts_cerdos    = cerdos_nuevos * PTS_CERDO
            pts_madera    = tablas_hit * PTS_MADERA
            puntaje       = pts_cerdos + pts_madera
            puntaje_total += puntaje

            tiro = {
                "partida":           partida_num,
                "intento":           intentos,
                "angulo":            round(math.degrees(angle), 2),
                "velocidad":         round(speed, 2),
                "distancia":         round(distance, 2),
                "tablas_golpeadas":  tablas_hit,
                "cerdos_derribados": cerdos_nuevos,
                "pts_madera":        pts_madera,
                "pts_cerdos":        pts_cerdos,
                "bonus_intento":     bonus,
                "puntaje_intento":   puntaje,
                "puntaje_acumulado": puntaje_total,
                # 3 puntos clave en coordenadas cartesianas escaladas (1 unidad = cell/scale px)
                "A_x": 0, "A_y": 0,
                "B_x": round((min(full_trail[-1], key=lambda p: p[1])[0] - x0) / 25 * 10, 1) if full_trail and full_trail[-1] else "",
                "B_y": round((GROUND_Y - min(full_trail[-1], key=lambda p: p[1])[1]) / 25 * 10, 1) if full_trail and full_trail[-1] else "",
                "C_x": round((full_trail[-1][-1][0] - x0) / 25 * 10, 1) if full_trail and full_trail[-1] else "",
                "C_y": 0,
            }
            data.append(tiro)
            partida_intentos.append(tiro)
            print(tiro)
            shooting = False
            trail.clear()

            if all(not p[3] for p in st["pigs"]):
                # resumen de partida en consola
                print(f"\n=== Partida {partida_num} terminada en {intentos} intentos ===")
                for t in partida_intentos:
                    print(f"  Tiro {t['intento']}: angulo={t['angulo']}° vel={t['velocidad']} dist={t['distancia']} cerdos={t['cerdos_derribados']} pts={t['puntaje_intento']}")
                print(f"  Puntaje partida: {puntaje_total}\n")
                partida_num      += 1
                intentos          = 0
                partida_intentos  = []
                full_trail        = []
                st = make_structure()

    update_physics()

    # trayectoria permanente — cada tiro dibujado por separado
    for tiro_trail in full_trail:
        if len(tiro_trail) > 1:
            pygame.draw.lines(screen, (255, 80, 80), False, tiro_trail, 2)

    # trayectoria animada (cola)
    for i, (tx, ty) in enumerate(trail):
        alpha = int(200 * i / max(len(trail), 1))
        pygame.draw.circle(screen, (alpha, alpha, 255), (tx, ty), 3)

    draw_slingshot()
    draw_structure()
    draw_bird(x, y)

    for i, txt in enumerate([
        f"Partida: {partida_num}",
        f"Intentos: {intentos}",
        f"Angulo: {round(math.degrees(angle),1)}°",
        f"Velocidad: {round(speed,1)}",
        f"Puntaje: {puntaje_total}",
        f"Cerdo +{PTS_CERDO}  Madera +{PTS_MADERA}",
    ]):
        screen.blit(font_big.render(txt, True, BLACK), (10, 10 + i * 26))

    if show_grid:
        grid_surf = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        cell  = 25   # tamaño visual de cada celda en px
        scale = 10   # cada celda representa 10 unidades
        ox = x0        # origen X = resortera
        oy = GROUND_Y  # origen Y = suelo
        # líneas verticales
        for gx in range(0, WIDTH, cell):
            steps = (gx - ox) // cell
            coord = steps * scale
            alpha = 180 if coord % 50 == 0 else 60
            pygame.draw.line(grid_surf, (0, 0, 0, alpha), (gx, 0), (gx, HEIGHT), 1)
            if coord % 50 == 0 and coord != 0:
                lbl = font.render(str(coord), True, (0, 0, 0, 220))
                grid_surf.blit(lbl, (gx + 2, oy + 4))
        # líneas horizontales
        for gy in range(0, HEIGHT, cell):
            steps = (oy - gy) // cell
            coord = steps * scale
            alpha = 180 if coord % 50 == 0 else 60
            pygame.draw.line(grid_surf, (0, 0, 0, alpha), (0, gy), (WIDTH, gy), 1)
            if coord % 50 == 0 and coord != 0:
                lbl = font.render(str(coord), True, (0, 0, 0, 220))
                grid_surf.blit(lbl, (ox + 4, gy + 2))
        # ejes principales
        pygame.draw.line(grid_surf, (200, 0, 0, 220), (0, oy), (WIDTH, oy), 2)   # eje X
        pygame.draw.line(grid_surf, (200, 0, 0, 220), (ox, 0), (ox, HEIGHT), 2)  # eje Y
        # origen
        lbl0 = font.render("0", True, (200, 0, 0, 220))
        grid_surf.blit(lbl0, (ox + 4, oy + 4))
        screen.blit(grid_surf, (0, 0))

    hint = font.render("H = hitbox  |  G = grilla  |  Mantén clic para cargar y suelta para lanzar", True, BLACK)
    if not shooting and not charging:
        screen.blit(hint, (WIDTH//2 - hint.get_width()//2, HEIGHT - 30))

    pygame.display.flip()

pygame.quit()
df = pd.DataFrame(data)
df.to_csv("datos_juego.csv", index=False)
print(f"\nPartida terminada — {intentos} intentos, puntaje total: {puntaje_total}")
print("Datos guardados en datos_juego.csv")
